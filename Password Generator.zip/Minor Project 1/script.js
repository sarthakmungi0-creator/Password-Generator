const password = document.getElementById("password");
const length = document.getElementById("length");
const lengthValue = document.getElementById("lengthValue");

const uppercase = document.getElementById("uppercase");
const lowercase = document.getElementById("lowercase");
const numbers = document.getElementById("numbers");
const symbols = document.getElementById("symbols");

const generateBtn = document.getElementById("generateBtn");
const copyBtn = document.getElementById("copyBtn");

length.addEventListener("input", () => {
    lengthValue.textContent = length.value;
});

const upperChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const lowerChars = "abcdefghijklmnopqrstuvwxyz";
const numberChars = "0123456789";
const symbolChars = "!@#$%^&*()_+-=[]{}|;:,.<>?";

generateBtn.addEventListener("click", () => {

    let chars = "";

    if (uppercase.checked) chars += upperChars;
    if (lowercase.checked) chars += lowerChars;
    if (numbers.checked) chars += numberChars;
    if (symbols.checked) chars += symbolChars;

    if (chars.length === 0) {
        alert("Please select at least one character type.");
        return;
    }

    let generatedPassword = "";

    for (let i = 0; i < length.value; i++) {
        const randomIndex = Math.floor(Math.random() * chars.length);
        generatedPassword += chars[randomIndex];
    }

    password.value = generatedPassword;
});

copyBtn.addEventListener("click", () => {

    if(password.value===""){
        alert("Generate a password first.");
        return;
    }

    navigator.clipboard.writeText(password.value);

    copyBtn.innerText="Copied!";

    setTimeout(()=>{
        copyBtn.innerText="Copy";
    },1500);

});